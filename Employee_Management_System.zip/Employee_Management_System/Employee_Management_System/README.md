This is a java project.
<br>
Employee Management System
